// config.js
const API_KEY = '9c095da267384cf0a9fccc8c7cb83ec5&ip'
export default API_KEY
